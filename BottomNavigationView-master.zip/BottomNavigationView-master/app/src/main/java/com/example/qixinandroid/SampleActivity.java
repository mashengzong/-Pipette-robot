package com.example.qixinandroid;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.Button;

/**
 * @ClassName: yangbenwei$
 * @Description: 作用描述
 * @Author: msz
 * @CreateDate: 2021/3/30$
 * @UpdateUser: updater
 * @UpdateDate: 2021/3/30$
 * @UpdateRemark: 更新内容
 * @Version: 1.0
 */
public class SampleActivity extends Activity {
    private Button fanhui;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitysample);
    }

//    @Override
//        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//            View view=inflater.inflate(R.layout.yangbenwei_fragment,null);
//
////            fanhui = view.findViewById(R.id.fanhui);
////            fanhui.setOnClickListener(new View.OnClickListener() {
////                @Override
////                public void onClick(View v) {
////                    Intent intent = new Intent(getActivity(),MainActivity.class);
////                    startActivity(intent);
////                }
////            });
//            return view;
//        }
    }
