package com.example.qixinandroid;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
/**
 * @ClassName: yangbenwei$
 * @Description: 作用描述
 * @Author: msz
 * @CreateDate: 2021/3/30$
 * @UpdateUser: updater
 * @UpdateDate: 2021/3/30$
 * @UpdateRemark: 更新内容
 * @Version: 1.0
 */

public class LampFragment extends Fragment {
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.lampfragment,null);

        return view;
    }
}