package com.example.qixinandroid;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

/**
 * @ClassName: yangbenwei$
 * @Description: 作用描述
 * @Author: msz
 * @CreateDate: 2021/3/30$
 * @UpdateUser: updater
 * @UpdateDate: 2021/3/30$
 * @UpdateRemark: 更新内容
 * @Version: 1.0
 */

public class MainActivity extends AppCompatActivity {


    private  BottomNavigationView bottomNavigationView;
    private Fragment aboutfragment;
    private Fragment debuggingfragment;
    private Fragment lampfragment;
    private Fragment functionfragment;
    private Fragment equipmentfragment;
    private Fragment[] fragments;
    private int lastfragment;//用于记录上个选择的Fragment

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        initFragment();
    }

    private void initFragment() {
        equipmentfragment = new EquipmentFragment();
        debuggingfragment = new DebuggingFragment();
        functionfragment = new FunctionFragment();
        lampfragment = new LampFragment();
        aboutfragment = new AboutFragment();
        fragments = new Fragment[]{equipmentfragment,debuggingfragment,functionfragment,lampfragment,aboutfragment};
        lastfragment = 0;
        getSupportFragmentManager().beginTransaction().replace(R.id.frame_fragment, equipmentfragment).show(equipmentfragment).commit();
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigationView);

        bottomNavigationView.setOnNavigationItemSelectedListener(changeFragment);
    }
    private BottomNavigationView.OnNavigationItemSelectedListener changeFragment = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()) {
                case R.id.item1: {
                    if (lastfragment != 0) {
                        switchFragment(lastfragment, 0);
                        lastfragment = 0;
                    }
                    return true;
                }
                case R.id.item2: {
                    if (lastfragment != 1) {
                        switchFragment(lastfragment, 1);
                        lastfragment = 1;

                    }

                    return true;
                }
                case R.id.item3: {
                    if (lastfragment != 2) {
                        switchFragment(lastfragment, 2);
                        lastfragment = 2;
                    }
                    return true;
                }
                case R.id.item4: {
                    if (lastfragment != 3) {
                        switchFragment(lastfragment, 3);
                        lastfragment = 3;
                    }
                    return true;
                }
                case R.id.item5: {
                    if (lastfragment != 4) {
                        switchFragment(lastfragment, 4);
                        lastfragment = 4;
                    }
                    return true;
                }
            }

            return false;
        }
    };


    //切换Fragment
    private void switchFragment(int lastfragment, int index) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.hide(fragments[lastfragment]);//隐藏上个Fragment
        if (fragments[index].isAdded() == false) {
            transaction.add(R.id.frame_fragment, fragments[index]);
        }
        transaction.show(fragments[index]).commitAllowingStateLoss();

    }

}
